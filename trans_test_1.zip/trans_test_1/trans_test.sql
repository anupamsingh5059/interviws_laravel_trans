-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 09, 2025 at 10:00 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `trans_test`
--

-- --------------------------------------------------------

--
-- Table structure for table `cache`
--

CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cache_locks`
--

CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `jobs`
--

INSERT INTO `jobs` (`id`, `queue`, `payload`, `attempts`, `reserved_at`, `available_at`, `created_at`) VALUES
(4, 'default', '{\"uuid\":\"bb9c16ae-c45b-42ac-b467-7ef78c5bbe1b\",\"displayName\":\"App\\\\Jobs\\\\ProcessOrderJob\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"App\\\\Jobs\\\\ProcessOrderJob\",\"command\":\"O:24:\\\"App\\\\Jobs\\\\ProcessOrderJob\\\":1:{s:10:\\\"\\u0000*\\u0000orderId\\\";i:25;}\"},\"createdAt\":1754722662,\"delay\":null}', 0, NULL, 1754722662, 1754722662),
(5, 'default', '{\"uuid\":\"4d4801a6-7257-4f4c-9b22-38e029e6ae4b\",\"displayName\":\"App\\\\Jobs\\\\ProcessOrderJob\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"App\\\\Jobs\\\\ProcessOrderJob\",\"command\":\"O:24:\\\"App\\\\Jobs\\\\ProcessOrderJob\\\":1:{s:10:\\\"\\u0000*\\u0000orderId\\\";i:26;}\"},\"createdAt\":1754725371,\"delay\":null}', 0, NULL, 1754725371, 1754725371),
(6, 'default', '{\"uuid\":\"0badec71-e838-4f70-9d6c-7b372746f7fb\",\"displayName\":\"App\\\\Jobs\\\\ProcessOrderJob\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"App\\\\Jobs\\\\ProcessOrderJob\",\"command\":\"O:24:\\\"App\\\\Jobs\\\\ProcessOrderJob\\\":1:{s:10:\\\"\\u0000*\\u0000orderId\\\";i:27;}\"},\"createdAt\":1754725384,\"delay\":null}', 0, NULL, 1754725384, 1754725384),
(7, 'default', '{\"uuid\":\"3c3b5fd5-eef8-4072-b16c-29a59673e2df\",\"displayName\":\"App\\\\Jobs\\\\ProcessOrderJob\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"App\\\\Jobs\\\\ProcessOrderJob\",\"command\":\"O:24:\\\"App\\\\Jobs\\\\ProcessOrderJob\\\":1:{s:10:\\\"\\u0000*\\u0000orderId\\\";i:28;}\"},\"createdAt\":1754725897,\"delay\":null}', 0, NULL, 1754725897, 1754725897),
(8, 'default', '{\"uuid\":\"882eb306-84bf-44c9-89cd-675fc7488802\",\"displayName\":\"App\\\\Jobs\\\\ProcessOrderJob\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"App\\\\Jobs\\\\ProcessOrderJob\",\"command\":\"O:24:\\\"App\\\\Jobs\\\\ProcessOrderJob\\\":1:{s:10:\\\"\\u0000*\\u0000orderId\\\";i:29;}\"},\"createdAt\":1754725910,\"delay\":null}', 0, NULL, 1754725910, 1754725910),
(9, 'default', '{\"uuid\":\"980e44ea-cf9d-4c67-9c36-4be37c8e84da\",\"displayName\":\"App\\\\Jobs\\\\ProcessOrderJob\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"App\\\\Jobs\\\\ProcessOrderJob\",\"command\":\"O:24:\\\"App\\\\Jobs\\\\ProcessOrderJob\\\":1:{s:10:\\\"\\u0000*\\u0000orderId\\\";i:30;}\"},\"createdAt\":1754725993,\"delay\":null}', 0, NULL, 1754725993, 1754725993),
(10, 'default', '{\"uuid\":\"5d059d66-d5ac-4ce1-8d71-15ffcb3f6a2a\",\"displayName\":\"App\\\\Jobs\\\\ProcessOrderJob\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"App\\\\Jobs\\\\ProcessOrderJob\",\"command\":\"O:24:\\\"App\\\\Jobs\\\\ProcessOrderJob\\\":1:{s:10:\\\"\\u0000*\\u0000orderId\\\";i:31;}\"},\"createdAt\":1754726004,\"delay\":null}', 0, NULL, 1754726004, 1754726004),
(11, 'default', '{\"uuid\":\"aca190a0-330b-46bd-a0d3-cb7b38e44956\",\"displayName\":\"App\\\\Jobs\\\\ProcessOrderJob\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"App\\\\Jobs\\\\ProcessOrderJob\",\"command\":\"O:24:\\\"App\\\\Jobs\\\\ProcessOrderJob\\\":1:{s:10:\\\"\\u0000*\\u0000orderId\\\";i:32;}\"},\"createdAt\":1754726021,\"delay\":null}', 0, NULL, 1754726021, 1754726021),
(12, 'default', '{\"uuid\":\"c95ec821-8c52-4b08-90fe-1f7e6fece763\",\"displayName\":\"App\\\\Jobs\\\\ProcessOrderJob\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"App\\\\Jobs\\\\ProcessOrderJob\",\"command\":\"O:24:\\\"App\\\\Jobs\\\\ProcessOrderJob\\\":1:{s:10:\\\"\\u0000*\\u0000orderId\\\";i:33;}\"},\"createdAt\":1754726049,\"delay\":null}', 0, NULL, 1754726049, 1754726049),
(13, 'default', '{\"uuid\":\"65d9811f-c85f-4259-8c3f-8fb13b902f6a\",\"displayName\":\"App\\\\Jobs\\\\ProcessOrderJob\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"App\\\\Jobs\\\\ProcessOrderJob\",\"command\":\"O:24:\\\"App\\\\Jobs\\\\ProcessOrderJob\\\":1:{s:10:\\\"\\u0000*\\u0000orderId\\\";i:34;}\"},\"createdAt\":1754726329,\"delay\":null}', 0, NULL, 1754726329, 1754726329);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2025_08_08_082158_create_users_table', 1),
(2, '2025_08_08_084134_create_orders_table', 1),
(3, '2025_08_08_090112_create_products_table', 2),
(4, '2025_08_08_163955_create_cache_table', 3),
(5, '2025_08_08_171307_create_jobs_table', 4);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_name` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `tras_no` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `order_name`, `price`, `user_id`, `tras_no`, `created_at`, `updated_at`) VALUES
(5, 'Google Pixel 2 XL', '400.00', NULL, 9022, '2025-08-08 06:23:34', '2025-08-08 06:23:34'),
(6, 'Google Pixel 2 XL', '400.00', NULL, 8573, '2025-08-08 06:24:26', '2025-08-08 06:24:26'),
(9, 'Apple iPhone 12', '500.00', NULL, 6050, '2025-08-08 10:28:06', '2025-08-08 10:28:06'),
(10, 'Apple iPhone 12', '500.00', NULL, 6294, '2025-08-08 10:30:20', '2025-08-08 10:30:20'),
(11, 'Apple iPhone 12', '500.00', NULL, 3486, '2025-08-08 10:39:14', '2025-08-08 10:39:14'),
(13, 'Apple iPhone 12', '500.00', NULL, 7533, '2025-08-08 11:48:51', '2025-08-08 11:48:51'),
(22, 'Apple iPhone 12', '500.00', NULL, 1180, '2025-08-08 12:28:12', '2025-08-08 12:28:12'),
(23, 'Apple iPhone 12', '500.00', NULL, 6082, '2025-08-08 22:58:16', '2025-08-08 22:58:16'),
(24, 'Apple iPhone 12', '500.00', NULL, 8105, '2025-08-08 23:19:56', '2025-08-08 23:19:56'),
(25, 'Apple iPhone 12', '500.00', NULL, 678, '2025-08-09 01:27:39', '2025-08-09 01:27:39'),
(26, 'Apple iPhone 12', '500.00', 2, 432, '2025-08-09 02:12:51', '2025-08-09 02:12:51'),
(27, 'Apple iPhone 12', '500.00', 2, 7715, '2025-08-09 02:13:04', '2025-08-09 02:13:04'),
(28, 'Apple iPhone 12', '500.00', 2, 1508, '2025-08-09 02:21:37', '2025-08-09 02:21:37'),
(29, 'Apple iPhone 12', '500.00', 2, 8461, '2025-08-09 02:21:49', '2025-08-09 02:21:49'),
(30, 'Apple iPhone 12', '500.00', 2, 7273, '2025-08-09 02:23:13', '2025-08-09 02:23:13'),
(31, 'Apple iPhone 12', '500.00', 2, 5305, '2025-08-09 02:23:24', '2025-08-09 02:23:24'),
(32, 'Apple iPhone 12', '500.00', 2, 5180, '2025-08-09 02:23:41', '2025-08-09 02:23:41'),
(33, 'Apple iPhone 12', '500.00', 2, 4433, '2025-08-09 02:24:08', '2025-08-09 02:24:08'),
(34, 'Apple iPhone 12', '500.00', 2, 472, '2025-08-09 02:28:49', '2025-08-09 02:28:49');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `price` decimal(6,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `image`, `price`, `created_at`, `updated_at`) VALUES
(1, 'Samsung Galaxy', 'Samsung Brand', 'https://dummyimage.com/200x300/000/fff&text=Samsung', 100.00, '2025-08-08 04:01:23', '2025-08-08 04:01:23'),
(2, 'Apple iPhone 12', 'Apple Brand', 'https://dummyimage.com/200x300/000/fff&text=Iphone', 500.00, '2025-08-08 04:01:23', '2025-08-08 04:01:23'),
(3, 'Google Pixel 2 XL', 'Google Pixel Brand', 'https://dummyimage.com/200x300/000/fff&text=Google', 400.00, '2025-08-08 04:01:23', '2025-08-08 04:01:23'),
(4, 'LG V10 H800', 'LG Brand', 'https://dummyimage.com/200x300/000/fff&text=LG', 200.00, '2025-08-08 04:01:23', '2025-08-08 04:01:23');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `password` varchar(60) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `mobile`, `password`, `address`, `created_at`, `updated_at`) VALUES
(1, 'anupam', 'anupamsingh5050511@gmail.com', NULL, '$2y$12$T.0gRtDS15EdYbB9ppHud.YTtW5naBVGV/RQF79f9pDm7twVM1rSq', NULL, '2025-08-09 11:16:11', '2025-08-09 11:16:11'),
(2, 'Anupam', 'anupamsingh@gmail.com', NULL, '$2y$12$wklbPAglws8e5KtsJ.FTouE1OIx9VHvix7tnB7YR2mB7E.FihwSHG', NULL, '2025-08-09 06:04:00', '2025-08-09 06:04:00');

-- --------------------------------------------------------

--
-- Table structure for table `verification`
--

CREATE TABLE `verification` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `code` varchar(65) NOT NULL,
  `expires_at` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `verification`
--

INSERT INTO `verification` (`id`, `user_id`, `code`, `expires_at`) VALUES
(2, 5, '0074', '2025-08-08'),
(3, 6, '8174', '2025-08-08'),
(4, 9, '6664', '2025-08-08'),
(5, 10, '5100', '2025-08-08'),
(6, 11, '9371', '2025-08-08'),
(7, 13, '7217', '2025-08-08'),
(16, 22, '7355', '2025-08-08'),
(17, 23, '9054', '2025-08-09'),
(18, 24, '2031', '2025-08-09');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cache`
--
ALTER TABLE `cache`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `cache_locks`
--
ALTER TABLE `cache_locks`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `verification`
--
ALTER TABLE `verification`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `verification`
--
ALTER TABLE `verification`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
