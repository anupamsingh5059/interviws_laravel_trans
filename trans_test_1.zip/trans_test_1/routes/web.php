<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProductController;

use App\Http\Middleware\UserAuth;
use App\Http\Middleware\Amdinmiddware;
use App\Http\Controllers\CustomAuthController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
*/


Route::get('/', [CustomAuthController::class, 'index'])->name('login');
Route::post('custom-login', [CustomAuthController::class, 'customLogin'])->name('login.custom'); 
Route::get('registration', [CustomAuthController::class, 'registration'])->name('register-user');
Route::post('custom-registration', [CustomAuthController::class, 'customRegistration'])->name('register.custom'); 
Route::get('signout', [CustomAuthController::class, 'signOut'])->name('signout');


Route::middleware(['admin_auth'])->group(function () {
    Route::get('dashboard', [CustomAuthController::class, 'dashboard']); 
    Route::get('/product', [ProductController::class, 'product']);  
    Route::get('cart', [ProductController::class, 'cart'])->name('cart');
    Route::get('add-to-cart/{id}', [ProductController::class, 'addToCart'])->name('add.to.cart');
    Route::patch('update-cart', [ProductController::class, 'update'])->name('update.cart');
    Route::delete('remove-from-cart', [ProductController::class, 'remove'])->name('remove.from.cart');
    
    
    Route::post('/checkout', [ProductController::class, 'placeOrder'])->name('checkout-data'); 
    Route::post('/placeOrder', [ProductController::class, 'Checkout'])->name('checkout-placeOrder'); 

   
});
/**Admin routes **/
Route::middleware('adminAuth')->prefix('admin')->group(function(){
    Route::get('/dashboard', [DashboardController::class, 'adminDashboard'])->name('adminDashboardShow');
});

/**Super Admin routes **/
Route::middleware('superAdminAuth')->group(function(){
    Route::get('/dashboard', [CustomAuthController::class, 'superAdminDashboard'])->name('superAdminDashboardShow');
});

Route::get('userdashboard', [CustomAuthController::class, 'generalUserDashboard'])->name('dashboard');

