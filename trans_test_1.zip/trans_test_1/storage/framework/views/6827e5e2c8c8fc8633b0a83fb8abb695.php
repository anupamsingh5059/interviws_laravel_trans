
   
<?php $__env->startSection('content'); ?> 
<div class="row mt-4">
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3">
            <div class="card text-center">
                <img src="<?php echo e($product->image); ?>" alt="" class="card-img-top">
                <div class="caption card-body">
                    <h4><?php echo e($product->name); ?></h4>
                    <p><?php echo e($product->description); ?></p>
                    <p><strong>Price: </strong> $ <?php echo e($product->price); ?></p>
                    <a href="<?php echo e(route('add.to.cart', $product->id)); ?>" class="btn btn-warning btn-block text-center" role="button">Add to cart</a>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-all\trans_test\resources\views/products.blade.php ENDPATH**/ ?>