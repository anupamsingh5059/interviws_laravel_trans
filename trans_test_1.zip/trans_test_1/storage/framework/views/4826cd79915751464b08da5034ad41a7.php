<html>

<head></head>

<body>
    <h1 id='sample'>My First Heading</h1>
    <p>My first paragraph.</p>
</body>

</html> <?php $__env->startSection('content'); ?>
<table id="cart" class="table table-hover table-condensed">
    <thead>
        <span class="btn btn-info" id="msg"></span>
        <tr>
            <th style="width:50%">Product</th>
            <th style="width:10%">Price</th>
            <th style="width:8%">Quantity</th>
            <th style="width:22%" class="text-center">Subtotal</th>
            <th style="width:10%"></th>
        </tr>
    </thead>
    <tbody>
        <?php $total = 0 ?> <?php if(session('cart')): ?> <?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php $total += $details['price'] * $details['quantity'] ?>
        <tr data-id="<?php echo e($id); ?>">
            <input type="hidden" name="product_id" id="product_id" value="<?php echo e($id); ?>">
            <td data-th="Product">
                <div class="row">
                    <div class="col-sm-3 hidden-xs"><img src="<?php echo e($details['image']); ?>" width="100" height="150" class="img-responsive" /></div>
                    <div class="col-sm-9">
                        <h4 class="nomargin"><?php echo e($details['name']); ?></h4>
                    </div>
                </div>
            </td>
            <td data-th="Price">$<?php echo e($details['price']); ?></td>
            <td data-th="Quantity">
                <input type="hidden" id="quantity" value="<?php echo e($details['quantity']); ?>" />
                <input type="number" value="<?php echo e($details['quantity']); ?>" class="form-control quantity update-cart" />
            </td>
            <td data-th="Subtotal" class="text-center">$<?php echo e($details['price'] * $details['quantity']); ?></td>
            <td class="actions" data-th="">
                <button class="btn btn-danger btn-sm remove-from-cart"><i class="fa fa-trash-o"></i></button>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php endif; ?>
    </tbody>
    <tfoot>
        <tr>
            <td colspan="5" class="text-right">
                <h3><strong>Total $<?php echo e($total); ?></strong></h3></td>
        </tr>
        <tr>
            <td colspan="5" class="text-right">
                <a href="<?php echo e(url('/')); ?>" class="btn btn-warning"><i class="fa fa-angle-left"></i> Continue Shopping</a>
                <button class="btn btn-success checkout-cart">Checkout</button>
            </td>
        </tr>
    </tfoot>
</table>
<?php $__env->stopSection(); ?> <?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
    $(".update-cart").change(function (e) {
        e.preventDefault();
  
        var ele = $(this);
  
        $.ajax({
            url: '<?php echo e(route('update.cart')); ?>',
            method: "patch",
            data: {
                _token: '<?php echo e(csrf_token()); ?>', 
                id: ele.parents("tr").attr("data-id"), 
                quantity: ele.parents("tr").find(".quantity").val()
            },
            success: function (response) {
               window.location.reload();
            }
        });
    });
  
    $(".remove-from-cart").click(function (e) {
        e.preventDefault();
  
        var ele = $(this);
  
        if(confirm("Are you sure want to remove?")) {
            $.ajax({
                url: '<?php echo e(route('remove.from.cart')); ?>',
                method: "DELETE",
                data: {
                    _token: '<?php echo e(csrf_token()); ?>', 
                    id: ele.parents("tr").attr("data-id")
                },
                success: function (response) {
                    window.location.reload();
                }
            });
        }
    });



    $(".checkout-cart").click(function (e) {
        e.preventDefault();
  
        let   productid=  $('#product_id').val();
        // alert(productid);
        let   quantity =  $('#quantity').val();
        //   alert(quantity);

      
        $.ajax({
            url: '<?php echo e(route('checkout-data')); ?>',
            method: "post",
            data: {
                _token: '<?php echo e(csrf_token()); ?>', 
                productid:productid,
                quantity:quantity
            },
            success: function (response) {
                // $("#msg").html(response.status);
                // $("#msg").fadeOut(5000);
                if (response.status === 'success') {
                    $("#msg").html(response.message); 
                      $("#msg").fadeOut(8000);
                    } else {
                    $("#msg").html("Something went wrong!");
                    $("#msg").fadeOut(8000);
                   }
            },
               
            

                error: function(xhr) {
                let res = xhr.responseJSON;
                alert(res.message || 'Server error!');
                }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-all\trans_test\resources\views/cart.blade.php ENDPATH**/ ?>