<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\Orders;
use App\Models\Verification;
use Illuminate\Support\Facades\DB;

use Carbon\Carbon;

use App\Jobs\ProcessOrderJob;

use Exception;

class ProductController extends Controller
{
    public function product()
    {
        $products = Product::all();
        return view("products", compact("products"));
    }

    public function cart()
    {
        return view("cart");
    }

    public function addToCart($id)
    {
        $product = Product::findOrFail($id);

        $cart = session()->get("cart", []);

        if (isset($cart[$id])) {
            $cart[$id]["quantity"]++;
        } else {
            $cart[$id] = [
                "name" => $product->name,
                "quantity" => 1,
                "price" => $product->price,
                "image" => $product->image,
            ];
        }

        session()->put("cart", $cart);
        return redirect()
            ->back()
            ->with("success", "Product added to cart successfully!");
    }

    public function update(Request $request)
    {
        if ($request->id && $request->quantity) {
            $cart = session()->get("cart");
            $cart[$request->id]["quantity"] = $request->quantity;
            session()->put("cart", $cart);
            session()->flash("success", "Cart updated successfully");
        }
    }

    public function remove(Request $request)
    {
        if ($request->id) {
            $cart = session()->get("cart");
            if (isset($cart[$request->id])) {
                unset($cart[$request->id]);
                session()->put("cart", $cart);
            }
            session()->flash("success", "Product removed successfully");
        }
    }

    public function Checkout(Request $request)
    {
        $id = $request->productid;
        $product = Product::findOrFail($id);

        try {
            DB::beginTransaction();
            $order = Orders::create([
                "order_name" => $product->name,
                "price" => $product->price,
                "tras_no" => str_pad(
                    random_int(0, 9999),
                    "4",
                    "0",
                    STR_PAD_LEFT
                ),
            ]);
            Verification::create([
                "user_id" => $order->id,
                "code" => str_pad(random_int(0, 9999), "4", "0", STR_PAD_LEFT),
                "expires_at" => Carbon::now()->addHours(2),
            ]);

            DB::commit();
            return response()->json(
                [
                    "message" => "Orders created successfully",
                    "status" => "success",
                ],
                200
            );

            ProcessOrderJob::dispatch($order->id)->delay(10);
        } catch (\Exception $exp) {
            DB::rollBack();
            return response()->json(
                [
                    "message" => $exp->getMessage(),
                    "status" => "failed",
                ],
                400
            );
        }
    }

    public function placeOrder(Request $request)
    {
        $id = $request->productid;
        $product = Product::findOrFail($id);
        DB::beginTransaction();

        try {
            $order = Orders::create([
                "user_id" => auth()->id(),
                // 'total_amount'  => $request->input('total_amount'),
                "order_name" => $product->name,
                "price" => $product->price,
                "tras_no" => str_pad(
                    random_int(0, 9999),
                    "4",
                    "0",
                    STR_PAD_LEFT
                ),
            ]);

            DB::commit();

            ProcessOrderJob::dispatch($order->id);

            return response()->json(
                [
                    "message" => "Order placed successfully",
                    "status" => "success",
                ],
                200
            );
        } catch (Exception $e) {
            DB::rollBack();

            return response()->json(
                [
                    "status" => "error",
                    "message" => "Failed to place order",
                    "error" => $e->getMessage(),
                ],
                500
            );
        }
    }
}
