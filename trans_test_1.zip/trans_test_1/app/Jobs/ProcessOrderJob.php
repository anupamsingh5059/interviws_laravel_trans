<?php

namespace App\Jobs;

use App\Models\Orders;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;  
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class ProcessOrderJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    protected $orderId;

 
    public function __construct($orderId)
    {
        $this->orderId = $orderId;
    }

  
    public function handle()
    {
        
        $order = Orders::findOrFail($this->orderId);

        
        foreach ($order->items as $item) {
            $item->product->decrement('stock', $item->quantity);
        }

    
    }
}


